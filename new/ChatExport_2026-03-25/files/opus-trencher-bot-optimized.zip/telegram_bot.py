from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from config import Config
from database import Database
from wallet_manager import WalletManager
from payment_processor import PaymentProcessor
from datetime import datetime

class TelegramBot:
    def __init__(self, db: Database):
        self.db = db
        self.payment_processor = PaymentProcessor(db)

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        username = update.effective_user.username
        
        user = self.db.get_user(user_id)
        if not user:
            address, private_key = WalletManager.generate_wallet()
            self.db.add_user(user_id, username, address, private_key)
            user = self.db.get_user(user_id)
            
        address = user[2]
        welcome_text = (
            f"Welcome to OPUS The Trencher Bot, {username}!\n\n"
            f"Your personal Solana deposit wallet:\n`{address}`\n\n"
            "Deposit SOL or OPUS tokens to this address to pay for subscriptions or use the autotrader."
        )
        
        keyboard = [
            [InlineKeyboardButton("CHECK BALANCE", callback_data="check_balance")],
            [InlineKeyboardButton("PAY NOW", callback_data="pay_now")],
            [InlineKeyboardButton("MEMBERSHIP STATUS", callback_data="membership_status")],
            [InlineKeyboardButton("MY REFERRALS", callback_data="my_referrals")],
            [InlineKeyboardButton("HOW IT WORKS", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        help_text = (
            "HOW IT WORKS:\n"
            "1. Deposit SOL or OPUS tokens to your unique wallet address.\n"
            "2. Select a subscription plan using the 'PAY NOW' button.\n"
            "3. Once active, you'll receive real-time pump.fun signals and can enable the Gold Au-Bot for autotrading.\n"
            "4. Share your referral link to earn 10% commission and free access days!"
        )
        await update.message.reply_text(help_text)

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id
        user = self.db.get_user(user_id)
        
        if query.data == "check_balance":
            address = user[2]
            sol, opus = WalletManager.get_balance(address)
            await query.edit_message_text(f"Wallet Balance:\nSOL: {sol:.4f}\nOPUS: {opus:,.0f}", 
                                         reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("REFRESH", callback_data="check_balance"), InlineKeyboardButton("BACK", callback_data="back_to_main")]]))
        
        elif query.data == "pay_now":
            keyboard = [
                [InlineKeyboardButton("Biweekly (170,000 OPUS)", callback_data="pay_biweekly")],
                [InlineKeyboardButton("Monthly (170,000 OPUS + 1.0 SOL)", callback_data="pay_monthly")],
                [InlineKeyboardButton("BACK", callback_data="back_to_main")]
            ]
            await query.edit_message_text("Select a plan:", reply_markup=InlineKeyboardMarkup(keyboard))
        
        elif query.data.startswith("pay_"):
            plan = query.data.split("_")[1]
            success, message = self.payment_processor.process_payment(user_id, plan)
            await query.edit_message_text(message, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("BACK", callback_data="back_to_main")]]))
        
        elif query.data == "membership_status":
            membership = self.db.get_membership(user_id)
            if membership and membership[3]:
                expiry = datetime.fromisoformat(membership[1])
                status = f"Status: ACTIVE\nExpiry: {expiry.strftime('%Y-%m-%d %H:%M')}"
            else:
                status = "Status: INACTIVE"
            await query.edit_message_text(status, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("RENEW", callback_data="pay_now"), InlineKeyboardButton("BACK", callback_data="back_to_main")]]))
        
        elif query.data == "my_referrals":
            count = self.db.get_referral_stats(user_id)
            ref_link = f"https://t.me/{(await context.bot.get_me()).username}?start={user_id}"
            text = f"Referral Stats:\nTotal Referrals: {count}\n\nYour Link:\n`{ref_link}`"
            await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("BACK", callback_data="back_to_main")]]), parse_mode="Markdown")
        
        elif query.data == "back_to_main":
            # Re-send the main menu logic
            address = user[2]
            welcome_text = (
                f"Your personal Solana deposit wallet:\n`{address}`\n\n"
                "Deposit SOL or OPUS tokens to this address to pay for subscriptions or use the autotrader."
            )
            keyboard = [
                [InlineKeyboardButton("CHECK BALANCE", callback_data="check_balance")],
                [InlineKeyboardButton("PAY NOW", callback_data="pay_now")],
                [InlineKeyboardButton("MEMBERSHIP STATUS", callback_data="membership_status")],
                [InlineKeyboardButton("MY REFERRALS", callback_data="my_referrals")],
                [InlineKeyboardButton("HOW IT WORKS", callback_data="help")]
            ]
            await query.edit_message_text(welcome_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode="Markdown")

    def run(self):
        application = Application.builder().token(Config.TELEGRAM_BOT_TOKEN).build()
        application.add_handler(CommandHandler("start", self.start))
        application.add_handler(CommandHandler("help", self.help_command))
        application.add_handler(CallbackQueryHandler(self.button_handler))
        # application.run_polling() # Will be called from main.py
        return application
