import asyncio
import threading
from config import Config
from database import Database
from telegram_bot import TelegramBot
from scanner import TokenScanner
from signals import SignalDistributor
from auto_trader import AutoTrader

def start_telegram_bot(bot_app):
    """Runs the Telegram bot in a separate thread."""
    bot_app.run_polling()

async def main():
    # Initialize components
    db = Database()
    bot_handler = TelegramBot(db)
    bot_app = bot_handler.run()
    
    # Signal distributor
    signal_distributor = SignalDistributor(db, bot_app.bot)
    
    # Signal scanner
    scanner = TokenScanner(db, signal_distributor.send_signal)
    
    # Auto trader
    auto_trader = AutoTrader(db)
    
    # Start Telegram Bot in a background thread
    print("Starting Telegram Bot...")
    bot_thread = threading.Thread(target=start_telegram_bot, args=(bot_app,))
    bot_thread.daemon = True
    bot_thread.start()
    
    # Start Token Scanner (main loop)
    print("Starting Token Scanner...")
    try:
        await scanner.scan_new_tokens()
    except KeyboardInterrupt:
        print("Bot stopped by user.")
    except Exception as e:
        print(f"Error in scanner loop: {e}")

if __name__ == "__main__":
    asyncio.run(main())
