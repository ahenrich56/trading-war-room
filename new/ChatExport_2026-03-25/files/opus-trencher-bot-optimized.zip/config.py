import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN")
    TREASURY_WALLET_ADDRESS = os.getenv("TREASURY_WALLET_ADDRESS", "YOUR_TREASURY_WALLET")
    SOLANA_RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
    PUMPPORTAL_API_KEY = os.getenv("PUMPPORTAL_API_KEY", "")
    
    # Subscription Prices
    BIWEEKLY_OPUS_PRICE = 170000
    MONTHLY_OPUS_PRICE = 170000
    MONTHLY_SOL_PRICE = 1.0
    
    # Referral Rewards
    REFERRAL_REWARD_PERCENT = 0.10
    REFERRAL_FREE_DAYS = 7
    REFERRED_FREE_DAYS = 2
    
    # Bot Settings
    SAFETY_SCORE_THRESHOLD = float(os.getenv("SAFETY_SCORE_THRESHOLD", "0.7"))
    MIN_INITIAL_LIQUIDITY = float(os.getenv("MIN_INITIAL_LIQUIDITY", "1000"))
    MIN_VOLUME = float(os.getenv("MIN_VOLUME", "500"))
    MAX_CONCURRENT_POSITIONS = int(os.getenv("MAX_CONCURRENT_POSITIONS", "3"))
    ENTRY_TIMING = os.getenv("ENTRY_TIMING", "immediate")
    SIGNAL_CHANNEL_ID = os.getenv("SIGNAL_CHANNEL_ID", "")
    AUTO_TRADER_ENABLED = os.getenv("AUTO_TRADER_ENABLED", "False").lower() == "true"
    
    # Trading Settings
    TAKE_PROFIT_MULTIPLIER = float(os.getenv("TAKE_PROFIT_MULTIPLIER", "5.0"))
    STOP_LOSS_MULTIPLIER = float(os.getenv("STOP_LOSS_MULTIPLIER", "0.5"))
    DEFAULT_BUY_AMOUNT_SOL = float(os.getenv("DEFAULT_BUY_AMOUNT_SOL", "50"))
