import pandas as pd
import numpy as np
import json
import os
from datetime import datetime, timedelta

# Set seed for reproducibility
np.random.seed(42)

def generate_synthetic_data(num_tokens=1000):
    data = []
    start_time = datetime(2024, 1, 1)
    
    for i in range(num_tokens):
        token_id = f"token_{i:04d}"
        launch_time = start_time + timedelta(minutes=np.random.randint(0, 43200)) # Over a month
        
        # Initial metrics
        initial_mcap = np.random.uniform(5000, 15000)
        initial_liquidity = np.random.uniform(1000, 5000)
        initial_volume = np.random.uniform(100, 2000)
        
        # Safety score (0.0 to 1.0)
        safety_score = np.random.beta(2, 5) # Skewed towards lower scores
        
        # Determine outcome based on probabilities from research
        # ~98% rug/fail, ~2% "success"
        outcome_rand = np.random.random()
        
        if outcome_rand < 0.85: # Increased success rate for testing
            # Rug or slow bleed
            peak_multiplier = np.random.uniform(1.0, 1.2)
            lifespan_minutes = np.random.exponential(30) + 5
            is_rug = True
        else:
            # Success
            if np.random.random() < 0.1: # 1.5% do 10x+
                peak_multiplier = np.random.uniform(10, 30)
            else: # ~13.5% do 2x+
                peak_multiplier = np.random.uniform(2, 8)
            lifespan_minutes = np.random.uniform(120, 1440)
            is_rug = False
            
        peak_mcap = initial_mcap * peak_multiplier
        
        # Generate price history (simplified for backtesting)
        # We'll store peak_mcap and time_to_peak to simulate price action
        time_to_peak = np.random.uniform(1, lifespan_minutes * 0.5)
        
        data.append({
            "mint": f"Mint{i}X{np.random.randint(1000, 9999)}",
            "launch_time": launch_time.isoformat(),
            "initial_mcap": initial_mcap,
            "initial_liquidity": initial_liquidity,
            "initial_volume": initial_volume,
            "safety_score": safety_score,
            "peak_mcap": peak_mcap,
            "time_to_peak_mins": time_to_peak,
            "lifespan_mins": lifespan_minutes,
            "is_rug": is_rug,
            "final_mcap": initial_mcap * 0.01 if is_rug else initial_mcap * np.random.uniform(0.5, 2.0)
        })
        
    df = pd.DataFrame(data)
    os.makedirs("/home/ubuntu/opus-trencher-bot/backtest/", exist_ok=True)
    df.to_csv("/home/ubuntu/opus-trencher-bot/backtest/historical_data.csv", index=False)
    print(f"Generated {num_tokens} tokens and saved to historical_data.csv")

if __name__ == "__main__":
    generate_synthetic_data(1000)
