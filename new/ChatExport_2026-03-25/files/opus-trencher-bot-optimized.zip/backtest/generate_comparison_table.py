import json
import pandas as pd

def generate_comparison_table(results_path, output_path, num_top_results=10):
    with open(results_path, 'r') as f:
        results = json.load(f)

    # Convert to DataFrame for easier sorting and selection
    df = pd.DataFrame([
        {
            **r['parameters'],
            **r['metrics']
        }
        for r in results
    ])

    # Sort by total_pnl and then sharpe_ratio to get top performing strategies
    df_sorted = df.sort_values(by=['total_pnl', 'sharpe_ratio'], ascending=[False, False])

    # Select top N results
    top_results = df_sorted.head(num_top_results)

    # Format for Markdown table
    table_content = "| Rank | Safety Score | Min Liq ($) | Min Vol ($) | TP Multiplier | SL Multiplier | Pos Size ($) | Max Concurrent | Total PnL ($) | Win Rate (%) | Max Drawdown ($) | Sharpe Ratio |\n"
    table_content += "|---|---|---|---|---|---|---|---|---|---|---|---|\n"

    for i, row in top_results.iterrows():
        table_content += f"| {i+1} "
        table_content += f"| {row['safety_score_threshold']:.1f} "
        table_content += f"| {row['min_initial_liquidity']:.0f} "
        table_content += f"| {row['min_volume']:.0f} "
        table_content += f"| {row['take_profit_multiplier']:.1f}x "
        table_content += f"| {row['stop_loss_multiplier']:.1f}x "
        table_content += f"| {row['position_size_sol']:.0f} "
        table_content += f"| {row['max_concurrent_positions']:.0f} "
        table_content += f"| {row['total_pnl']:.2f} "
        table_content += f"| {row['win_rate']:.2%} "
        table_content += f"| {row['max_drawdown']:.2f} "
        table_content += f"| {row['sharpe_ratio']:.2f} |\n"

    with open(output_path, 'w') as f:
        f.write(table_content)
    print(f"Generated comparison table to {output_path}")

if __name__ == "__main__":
    results_file = "/home/ubuntu/opus-trencher-bot/backtest/optimization_results.json"
    output_file = "/home/ubuntu/opus-trencher-bot/backtest/comparison_table.md"
    generate_comparison_table(results_file, output_file)
