import pandas as pd
import numpy as np
import json
from backtest import BacktestEngine, BacktestParams, asdict

def run_stress_test():
    # Load optimal parameters
    with open("/home/ubuntu/opus-trencher-bot/backtest/optimal_params.json", 'r') as f:
        optimal_data = json.load(f)
        params = BacktestParams(**optimal_data['parameters'])
    
    engine = BacktestEngine()
    stress_results = {}
    
    # 1. Bull Market Simulation (Success rate increased)
    print("Simulating Bull Market...")
    bull_df = engine.df.copy()
    # Boost peak multipliers by 50%
    bull_df['peak_mcap'] = bull_df['peak_mcap'] * 1.5
    engine.df = bull_df
    stress_results['bull_market'] = engine.run_backtest(params)
    
    # 2. Bear Market Simulation (Success rate decreased)
    print("Simulating Bear Market...")
    bear_df = pd.read_csv("/home/ubuntu/opus-trencher-bot/backtest/historical_data.csv")
    # Reduce peak multipliers by 50% and increase rug probability
    bear_df['peak_mcap'] = bear_df['peak_mcap'] * 0.5
    engine.df = bear_df
    stress_results['bear_market'] = engine.run_backtest(params)
    
    # 3. High Volatility / Liquidity Crunch
    print("Simulating Liquidity Crunch...")
    crunch_df = pd.read_csv("/home/ubuntu/opus-trencher-bot/backtest/historical_data.csv")
    # Increase slippage/stop loss hit rate
    params_crunch = BacktestParams(**optimal_data['parameters'])
    params_crunch.stop_loss_multiplier = 0.3 # Tighter SL/More slippage
    engine.df = crunch_df
    stress_results['liquidity_crunch'] = engine.run_backtest(params_crunch)
    
    # 4. 1000+ Trade Simulation (Bootstrap sampling)
    print("Simulating 1000+ trades via bootstrapping...")
    original_df = pd.read_csv("/home/ubuntu/opus-trencher-bot/backtest/historical_data.csv")
    bootstrap_df = original_df.sample(n=5000, replace=True)
    engine.df = bootstrap_df
    stress_results['long_term_sim'] = engine.run_backtest(params)
    
    # Save stress test results
    with open("/home/ubuntu/opus-trencher-bot/backtest/stress_test_results.json", 'w') as f:
        json.dump(stress_results, f, indent=2)
    
    print("\nSTRESS TEST RESULTS")
    print("="*60)
    for scenario, metrics in stress_results.items():
        print(f"Scenario: {scenario}")
        print(f"  Total PnL: {metrics['total_pnl']:.2f}")
        print(f"  Win Rate: {metrics['win_rate']:.2%}")
        print(f"  Max Drawdown: {metrics['max_drawdown']:.2f}")
        print("-" * 30)

if __name__ == "__main__":
    run_stress_test()
