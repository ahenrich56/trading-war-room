import pandas as pd
import numpy as np
import json
import os
from datetime import datetime
from itertools import product
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple

@dataclass
class BacktestParams:
    """Configuration for a backtest run."""
    safety_score_threshold: float  # 0.3 to 0.8
    min_initial_liquidity: float   # $1K to $20K
    min_volume: float              # $500 to $10K
    take_profit_multiplier: float  # 1.5x, 2x, 3x, 5x, 10x
    stop_loss_multiplier: float    # 0.2, 0.3, 0.5 (20%, 30%, 50% loss)
    position_size_sol: float       # $10 to $100
    max_concurrent_positions: int  # 3, 5, 10
    entry_timing: str              # "immediate" or "wait_confirmation"

@dataclass
class Trade:
    """Represents a single trade."""
    token_id: str
    entry_mcap: float
    entry_time: str
    exit_mcap: float
    exit_time: str
    exit_reason: str  # "TP", "SL", "Timeout"
    pnl: float
    pnl_percent: float
    position_size: float

class BacktestEngine:
    def __init__(self, data_path: str = "/home/ubuntu/opus-trencher-bot/backtest/historical_data.csv"):
        self.df = pd.read_csv(data_path)
        self.trades: List[Trade] = []
        self.open_positions: Dict = {}
        self.results = {}
        
    def filter_tokens(self, params: BacktestParams) -> pd.DataFrame:
        """Apply safety filters to tokens."""
        filtered = self.df[
            (self.df['safety_score'] >= params.safety_score_threshold) &
            (self.df['initial_liquidity'] >= params.min_initial_liquidity) &
            (self.df['initial_volume'] >= params.min_volume)
        ].copy()
        return filtered
    
    def simulate_trade(self, token_row, params: BacktestParams) -> Trade:
        """Simulate a single trade based on token data and parameters."""
        entry_mcap = token_row['initial_mcap']
        entry_time = token_row['launch_time']
        position_size = params.position_size_sol
        
        # Calculate exit levels
        tp_level = entry_mcap * params.take_profit_multiplier
        sl_level = entry_mcap * params.stop_loss_multiplier
        
        # Simulate price movement
        peak_mcap = token_row['peak_mcap']
        time_to_peak = token_row['time_to_peak_mins']
        lifespan = token_row['lifespan_mins']
        final_mcap = token_row['final_mcap']
        
        # Simple simulation: price goes to peak, then either rugs or recovers
        exit_mcap = entry_mcap
        exit_reason = "Timeout"
        exit_time = entry_time  # Placeholder
        
        # Check if TP is hit
        if peak_mcap >= tp_level:
            exit_mcap = tp_level
            exit_reason = "TP"
        # Check if SL is hit
        elif final_mcap <= sl_level:
            exit_mcap = sl_level
            exit_reason = "SL"
        # Otherwise, exit at final price
        else:
            exit_mcap = final_mcap
            exit_reason = "Timeout"
        
        pnl_percent = (exit_mcap - entry_mcap) / entry_mcap
        pnl = position_size * pnl_percent
        
        trade = Trade(
            token_id=token_row['mint'],
            entry_mcap=entry_mcap,
            entry_time=entry_time,
            exit_mcap=exit_mcap,
            exit_time=exit_time,
            exit_reason=exit_reason,
            pnl=pnl,
            pnl_percent=pnl_percent,
            position_size=position_size
        )
        
        return trade
    
    def run_backtest(self, params: BacktestParams) -> Dict:
        """Run a complete backtest with given parameters."""
        self.trades = []
        self.open_positions = {}
        
        # Filter tokens
        filtered_tokens = self.filter_tokens(params)
        
        if len(filtered_tokens) == 0:
            return {
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0,
                "win_rate": 0.0,
                "total_pnl": 0.0,
                "avg_return": 0.0,
                "best_trade": 0.0,
                "worst_trade": 0.0,
                "max_drawdown": 0.0,
                "sharpe_ratio": 0.0
            }
        
        # Simulate trades
        for idx, row in filtered_tokens.iterrows():
            if len(self.open_positions) < params.max_concurrent_positions:
                trade = self.simulate_trade(row, params)
                self.trades.append(trade)
                self.open_positions[row['mint']] = trade
            
            # Close expired positions
            expired = [k for k, v in self.open_positions.items() if v.exit_reason != "Timeout"]
            for k in expired:
                del self.open_positions[k]
        
        # Calculate metrics
        return self._calculate_metrics()
    
    def _calculate_metrics(self) -> Dict:
        """Calculate performance metrics from trades."""
        if len(self.trades) == 0:
            return {
                "total_trades": 0,
                "winning_trades": 0,
                "losing_trades": 0,
                "win_rate": 0.0,
                "total_pnl": 0.0,
                "avg_return": 0.0,
                "best_trade": 0.0,
                "worst_trade": 0.0,
                "max_drawdown": 0.0,
                "sharpe_ratio": 0.0
            }
        
        trades_df = pd.DataFrame([asdict(t) for t in self.trades])
        
        total_trades = len(self.trades)
        winning_trades = len(trades_df[trades_df['pnl'] > 0])
        losing_trades = len(trades_df[trades_df['pnl'] <= 0])
        win_rate = winning_trades / total_trades if total_trades > 0 else 0.0
        
        total_pnl = trades_df['pnl'].sum()
        avg_return = trades_df['pnl_percent'].mean()
        best_trade = trades_df['pnl'].max()
        worst_trade = trades_df['pnl'].min()
        
        # Calculate max drawdown
        cumulative_pnl = trades_df['pnl'].cumsum()
        running_max = cumulative_pnl.expanding().max()
        drawdown = cumulative_pnl - running_max
        max_drawdown = drawdown.min()
        
        # Calculate Sharpe ratio (assuming 0% risk-free rate)
        returns = trades_df['pnl_percent'].values
        if len(returns) > 1 and np.std(returns) > 0:
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252)  # Annualized
        else:
            sharpe_ratio = 0.0
        
        return {
            "total_trades": total_trades,
            "winning_trades": winning_trades,
            "losing_trades": losing_trades,
            "win_rate": win_rate,
            "total_pnl": total_pnl,
            "avg_return": avg_return,
            "best_trade": best_trade,
            "worst_trade": worst_trade,
            "max_drawdown": max_drawdown,
            "sharpe_ratio": sharpe_ratio
        }
    
    def parameter_sweep(self, param_ranges: Dict) -> List[Tuple[BacktestParams, Dict]]:
        """Run backtests across all parameter combinations."""
        results = []
        
        # Generate all combinations
        keys = list(param_ranges.keys())
        values = [param_ranges[k] for k in keys]
        
        total_combinations = np.prod([len(v) for v in values])
        print(f"Running {total_combinations} parameter combinations...")
        
        count = 0
        for combo in product(*values):
            params = BacktestParams(
                safety_score_threshold=combo[0],
                min_initial_liquidity=combo[1],
                min_volume=combo[2],
                take_profit_multiplier=combo[3],
                stop_loss_multiplier=combo[4],
                position_size_sol=combo[5],
                max_concurrent_positions=combo[6],
                entry_timing=combo[7]
            )
            
            metrics = self.run_backtest(params)
            results.append((params, metrics))
            
            count += 1
            if count % 50 == 0:
                print(f"  Completed {count}/{total_combinations} combinations...")
        
        print(f"Completed all {total_combinations} combinations!")
        return results
    
    def find_optimal_parameters(self, results: List[Tuple[BacktestParams, Dict]]) -> Tuple[BacktestParams, Dict]:
        """Find the parameter combination with best risk-adjusted return."""
        best_score = -np.inf
        best_params = None
        best_metrics = None
        
        for params, metrics in results:
            # Score: maximize PnL while minimizing drawdown
            # Weight: 70% PnL, 30% Sharpe ratio (risk-adjusted)
            if metrics['total_trades'] == 0:
                continue
            
            pnl_score = metrics['total_pnl']
            sharpe_score = metrics['sharpe_ratio']
            
            # Composite score
            score = (0.7 * pnl_score) + (0.3 * sharpe_score * 100)
            
            if score > best_score:
                best_score = score
                best_params = params
                best_metrics = metrics
        
        return best_params, best_metrics
    
    def save_results(self, results: List[Tuple[BacktestParams, Dict]], output_path: str):
        """Save optimization results to JSON."""
        data = []
        for params, metrics in results:
            data.append({
                "parameters": asdict(params),
                "metrics": metrics
            })
        
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
        print(f"Saved results to {output_path}")
    
    def export_trades(self, output_path: str):
        """Export trades to CSV."""
        trades_df = pd.DataFrame([asdict(t) for t in self.trades])
        trades_df.to_csv(output_path, index=False)
        print(f"Exported {len(self.trades)} trades to {output_path}")


def main():
    engine = BacktestEngine()
    
    # Define parameter ranges for optimization
    param_ranges = {
        "safety_score_threshold": [0.3, 0.5, 0.7],
        "min_initial_liquidity": [1000, 5000, 10000],
        "min_volume": [500, 1000, 2000],
        "take_profit_multiplier": [1.5, 2.0, 3.0, 5.0],
        "stop_loss_multiplier": [0.2, 0.3, 0.5],
        "position_size_sol": [10, 25, 50],
        "max_concurrent_positions": [3, 5, 10],
        "entry_timing": ["immediate"]
    }
    
    # Run parameter sweep
    results = engine.parameter_sweep(param_ranges)
    
    # Save all results
    engine.save_results(results, "/home/ubuntu/opus-trencher-bot/backtest/optimization_results.json")
    
    # Find optimal parameters
    optimal_params, optimal_metrics = engine.find_optimal_parameters(results)
    
    print("\n" + "="*60)
    print("OPTIMAL PARAMETERS FOUND")
    print("="*60)
    print(json.dumps(asdict(optimal_params), indent=2))
    print("\nOPTIMAL METRICS")
    print("="*60)
    print(json.dumps(optimal_metrics, indent=2))
    
    # Save optimal parameters
    with open("/home/ubuntu/opus-trencher-bot/backtest/optimal_params.json", 'w') as f:
        json.dump({
            "parameters": asdict(optimal_params),
            "metrics": optimal_metrics
        }, f, indent=2)
    
    # Run final backtest with optimal parameters and export trades
    engine.run_backtest(optimal_params)
    engine.export_trades("/home/ubuntu/opus-trencher-bot/backtest/optimal_trades.csv")
    
    print("\nBacktesting complete!")


if __name__ == "__main__":
    main()
