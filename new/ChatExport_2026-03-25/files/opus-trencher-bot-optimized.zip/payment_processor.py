from config import Config
from wallet_manager import WalletManager
from database import Database
from datetime import datetime, timedelta

class PaymentProcessor:
    def __init__(self, db: Database):
        self.db = db

    def process_payment(self, user_id, plan_type):
        """Checks balance and transfers funds to treasury."""
        user = self.db.get_user(user_id)
        if not user:
            return False, "User not found."
        
        address = user[2]
        private_key = user[3]
        
        sol_balance, opus_balance = WalletManager.get_balance(address)
        
        if plan_type == "biweekly":
            if opus_balance < Config.BIWEEKLY_OPUS_PRICE:
                return False, f"Insufficient OPUS tokens. Required: {Config.BIWEEKLY_OPUS_PRICE} OPUS."
            
            # Transfer OPUS tokens
            success, tx_sig = WalletManager.transfer_funds(private_key, Config.TREASURY_WALLET_ADDRESS, amount_tokens=Config.BIWEEKLY_OPUS_PRICE)
            if success:
                expiry_date = datetime.now() + timedelta(days=14)
                self.db.update_membership(user_id, expiry_date.isoformat(), "biweekly")
                return True, "Biweekly subscription activated!"
            else:
                return False, f"Transfer failed: {tx_sig}"
        
        elif plan_type == "monthly":
            if opus_balance < Config.MONTHLY_OPUS_PRICE or sol_balance < Config.MONTHLY_SOL_PRICE:
                return False, f"Insufficient funds. Required: {Config.MONTHLY_OPUS_PRICE} OPUS + {Config.MONTHLY_SOL_PRICE} SOL."
            
            # Transfer OPUS and SOL
            success_opus, tx_sig_opus = WalletManager.transfer_funds(private_key, Config.TREASURY_WALLET_ADDRESS, amount_tokens=Config.MONTHLY_OPUS_PRICE)
            success_sol, tx_sig_sol = WalletManager.transfer_funds(private_key, Config.TREASURY_WALLET_ADDRESS, amount_sol=Config.MONTHLY_SOL_PRICE)
            
            if success_opus and success_sol:
                expiry_date = datetime.now() + timedelta(days=30)
                self.db.update_membership(user_id, expiry_date.isoformat(), "monthly")
                return True, "Monthly subscription activated!"
            else:
                return False, "Transfer failed for one or both assets."
        
        return False, "Invalid plan type."
