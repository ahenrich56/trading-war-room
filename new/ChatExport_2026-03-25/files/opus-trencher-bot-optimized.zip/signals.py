from telegram import Bot
from config import Config
from database import Database

class SignalDistributor:
    def __init__(self, db: Database, bot: Bot):
        self.db = db
        self.bot = bot
        self.channel_id = Config.SIGNAL_CHANNEL_ID

    async def send_signal(self, signal_data):
        """Sends a signal to the Telegram channel for subscribed users."""
        mint = signal_data.get("mint")
        name = signal_data.get("name")
        entry_mcap = signal_data.get("entry_mcap")
        safety_score = signal_data.get("safety_score")
        
        # Log signal to database
        self.db._get_connection().execute('''
            INSERT INTO signals (token_ca, token_name, market_cap, safety_score)
            VALUES (?, ?, ?, ?)
        ''', (mint, name, entry_mcap, safety_score))
        
        # Message for Telegram channel
        signal_message = (
            f"🚀 **NEW SIGNAL DETECTED** 🚀\n\n"
            f"**Token:** {name}\n"
            f"**CA:** `{mint}`\n"
            f"**Entry Market Cap:** ${entry_mcap:,.0f}\n"
            f"**Safety Score:** {safety_score}/100\n\n"
            f"🔗 [View on pump.fun](https://pump.fun/{mint})"
        )
        
        if self.channel_id:
            try:
                await self.bot.send_message(chat_id=self.channel_id, text=signal_message, parse_mode="Markdown")
            except Exception as e:
                print(f"Error sending signal to channel: {e}")
        
        # For the replica bot, we'll also print to console
        print(f"Signal Distributed: {name} ({mint})")
