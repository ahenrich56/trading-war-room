import asyncio
import websockets
import json
from config import Config
from database import Database

class TokenScanner:
    def __init__(self, db: Database, signal_callback):
        self.db = db
        self.signal_callback = signal_callback
        self.uri = "wss://pumpportal.fun/api/data"

    async def scan_new_tokens(self):
        """Streams new token creation events from PumpPortal."""
        async with websockets.connect(self.uri) as websocket:
            # Subscribe to token creation events
            payload = {
                "method": "subscribeNewToken",
            }
            await websocket.send(json.dumps(payload))
            
            async for message in websocket:
                data = json.loads(message)
                if data.get("txType") == "create":
                    await self._process_token(data)

    async def _process_token(self, token_data):
        """Filters and scores new tokens."""
        mint = token_data.get("mint")
        name = token_data.get("name")
        symbol = token_data.get("symbol")
        v_sol_in_bonding_curve = token_data.get("vSolInBondingCurve", 0)
        
        # Simple safety score based on initial metrics
        # (In a real scenario, this would involve developer history, volume patterns, etc.)
        safety_score = 50.0 # Default score
        
        # Filter by initial liquidity (vSolInBondingCurve)
        if v_sol_in_bonding_curve > 30: # Example threshold
            safety_score += 10
        
        # Entry market cap (initial bonding curve state)
        entry_mcap = 10000 # Placeholder for initial mcap calculation
        
        signal = {
            "mint": mint,
            "name": f"{name} ({symbol})",
            "entry_mcap": entry_mcap,
            "safety_score": safety_score
        }
        
        # Notify subscribed users via callback
        await self.signal_callback(signal)

    def run(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self.scan_new_tokens())
