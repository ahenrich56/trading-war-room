import sqlite3
import threading
import os


class Database:
    def __init__(self, db_path="opus_bot.db"):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def _init_db(self):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS users (
                        user_id INTEGER PRIMARY KEY,
                        username TEXT,
                        wallet_address TEXT UNIQUE,
                        private_key TEXT,
                        referred_by INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')

                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS memberships (
                        user_id INTEGER PRIMARY KEY,
                        expiry_date TIMESTAMP,
                        plan_type TEXT,
                        is_active BOOLEAN DEFAULT 0,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')

                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS referrals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        referrer_id INTEGER,
                        referred_id INTEGER,
                        reward_paid BOOLEAN DEFAULT 0,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (referrer_id) REFERENCES users (user_id),
                        FOREIGN KEY (referred_id) REFERENCES users (user_id)
                    )
                ''')

                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS signals (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        token_ca TEXT,
                        token_name TEXT,
                        market_cap REAL,
                        safety_score REAL,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                ''')

                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS trades (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        token_ca TEXT,
                        buy_price REAL,
                        sell_price REAL,
                        amount REAL,
                        pnl REAL,
                        status TEXT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users (user_id)
                    )
                ''')

                conn.commit()

    def add_user(self, user_id, username, wallet_address, private_key, referred_by=None):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR IGNORE INTO users (user_id, username, wallet_address, private_key, referred_by)
                    VALUES (?, ?, ?, ?, ?)
                ''', (user_id, username, wallet_address, private_key, referred_by))
                conn.commit()

    def get_user(self, user_id):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
                return cursor.fetchone()

    def update_membership(self, user_id, expiry_date, plan_type, is_active=1):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO memberships (user_id, expiry_date, plan_type, is_active)
                    VALUES (?, ?, ?, ?)
                ''', (user_id, expiry_date, plan_type, is_active))
                conn.commit()

    def get_membership(self, user_id):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM memberships WHERE user_id = ?', (user_id,))
                return cursor.fetchone()

    def add_referral(self, referrer_id, referred_id):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO referrals (referrer_id, referred_id)
                    VALUES (?, ?)
                ''', (referrer_id, referred_id))
                conn.commit()

    def get_referral_stats(self, user_id):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT COUNT(*) FROM referrals WHERE referrer_id = ?', (user_id,))
                return cursor.fetchone()[0]

    def add_signal(self, token_ca, token_name, market_cap, safety_score):
        with self._lock:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO signals (token_ca, token_name, market_cap, safety_score)
                    VALUES (?, ?, ?, ?)
                ''', (token_ca, token_name, market_cap, safety_score))
                conn.commit()
