# Polymarket OpenClaw Bot

This project implements an automated trading bot for Polymarket prediction markets, designed to identify and capitalize on mispricings using AI analysis. The bot includes features for risk management, persistent state, API retry logic, rate limiting, and a paper trading mode.

## Project Structure

```
polymarket-openclaw-bot/
├── .env
├── requirements.txt
├── bot.py          ← Main entry point, orchestrates scanning, analysis, and trading
├── scanner.py      ← Market data retrieval from Polymarket APIs
├── analyzer.py     ← Claude AI for market probability analysis
├── trader.py       ← Order execution on Polymarket CLOB
├── risk.py         ← Risk management, position sizing, and PnL tracking
└── logger.py       ← Logging and Telegram alerts
```

## Setup Instructions

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-repo/polymarket-openclaw-bot.git
    cd polymarket-openclaw-bot
    ```

2.  **Install dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Configure environment variables:**
    Create a `.env` file in the root directory of the project based on the `.env.example` provided below.

4.  **Run the bot:**
    ```bash
    python bot.py
    ```

## Configuration Guide

Create a `.env` file in the project root with the following variables:

```ini
POLYGON_WALLET_PRIVATE_KEY=your_polygon_private_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
TELEGRAM_CHAT_ID=your_chat_id_here

# Risk settings
MAX_POSITION_SIZE=200         # Maximum USD to allocate per position
MAX_OPEN_POSITIONS=5          # Maximum number of concurrent open positions
MIN_EDGE_THRESHOLD=0.15       # Minimum edge (difference between estimated and market probability) to consider a trade
DAILY_LOSS_LIMIT=300          # Maximum USD loss allowed per day before stopping trades

# Set to True for paper trading, False for live trading
PAPER_TRADING_MODE=True
```

-   **`POLYGON_WALLET_PRIVATE_KEY`**: Your private key for a Polygon wallet. **Be extremely careful with this key.**
-   **`ANTHROPIC_API_KEY`**: Your API key for Anthropic (Claude AI).
-   **`TELEGRAM_BOT_TOKEN`**: Token for your Telegram bot (obtained from BotFather).
-   **`TELEGRAM_CHAT_ID`**: Your Telegram chat ID where the bot will send alerts.
-   **`MAX_POSITION_SIZE`**: The maximum amount of USDC (or equivalent) to allocate to a single trade.
-   **`MAX_OPEN_POSITIONS`**: The maximum number of trades the bot can have open simultaneously.
-   **`MIN_EDGE_THRESHOLD`**: The minimum difference between the AI's estimated probability and the market's implied probability for a trade to be considered.
-   **`DAILY_LOSS_LIMIT`**: The maximum cumulative loss the bot can incur in a single day before it stops trading.
-   **`PAPER_TRADING_MODE`**: Set to `True` to simulate trades without real money. Set to `False` for live trading (use with extreme caution).

## Improvements Made

This bot has been significantly improved for profitability and robustness with the following features:

1.  **API Retry Logic (`scanner.py`)**:
    -   Implemented exponential backoff and retry attempts for API calls to Polymarket's Gamma and CLOB APIs. This enhances robustness against transient network issues or API rate limits, ensuring more reliable data fetching.

2.  **Position Monitoring and Auto-Exit Logic (`bot.py`)**:
    -   The `monitor_positions` function periodically checks all open positions.
    -   **Profit Taking**: Automatically closes positions if the market is near resolution (e.g., price > 0.95 for YES, < 0.05 for NO) and the position is profitable.
    -   **Stop Loss**: Implemented a simple stop-loss mechanism that closes a position if the market price moves significantly (e.g., 10%) against the entry price. This helps limit potential losses.

3.  **Paper Trading Mode (`.env`, `trader.py`, `bot.py`)**:
    -   A `PAPER_TRADING_MODE` environment variable allows switching between simulated and live trading. When enabled, `trader.py` logs trade intentions and sends Telegram alerts without executing actual orders on the CLOB.

4.  **Persistent State (`risk.py`)**:
    -   The `RiskManager` now saves and loads open positions to/from a `open_positions.json` file. This ensures that the bot can be restarted without losing track of its active trades, crucial for long-running operations.

5.  **Improved Kelly Criterion Position Sizing (`risk.py`)**:
    -   The `calculate_position_size` function in `risk.py` has been enhanced to use a more nuanced Kelly-inspired approach. It considers both the estimated probability and current market price, applying a fraction of the calculated Kelly bet based on the AI's confidence level (low, medium, high) to manage risk more effectively.

6.  **Rate Limiting (`trader.py`)**:
    -   A simple rate-limiting mechanism has been added to `trader.py` to prevent hitting API limits when posting orders to the CLOB. It introduces a delay between consecutive API calls.

7.  **Health Check Heartbeat (`bot.py`)**:
    -   The bot now sends periodic 
health check messages to Telegram, indicating that it is alive and running. This helps in monitoring the bot's operational status.

## Future Improvements

-   **Dynamic Kelly Multiplier**: Implement a dynamic Kelly multiplier based on market volatility or bot performance.
-   **Advanced Order Types**: Explore using more advanced order types (e.g., stop-limit, OCO) if supported by Polymarket CLOB.
-   **Market Event Monitoring**: Integrate real-time news or event monitoring to provide more context to the AI analyzer.
-   **Backtesting Framework**: Develop a backtesting framework to test strategies against historical market data.
-   **Parameter Optimization**: Implement a system for optimizing risk management and position sizing parameters.
