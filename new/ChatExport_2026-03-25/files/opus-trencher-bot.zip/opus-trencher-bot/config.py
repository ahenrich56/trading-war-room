import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN")
    TREASURY_WALLET_ADDRESS = os.getenv("TREASURY_WALLET_ADDRESS", "YOUR_TREASURY_WALLET")
    SOLANA_RPC_URL = os.getenv("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com")
    PUMPPORTAL_API_KEY = os.getenv("PUMPPORTAL_API_KEY", "")
    
    # Subscription Prices
    BIWEEKLY_OPUS_PRICE = 170000
    MONTHLY_OPUS_PRICE = 170000
    MONTHLY_SOL_PRICE = 1.0
    
    # Referral Rewards
    REFERRAL_REWARD_PERCENT = 0.10
    REFERRAL_FREE_DAYS = 7
    REFERRED_FREE_DAYS = 2
    
    # Bot Settings
    SIGNAL_CHANNEL_ID = os.getenv("SIGNAL_CHANNEL_ID", "")
    AUTO_TRADER_ENABLED = os.getenv("AUTO_TRADER_ENABLED", "False").lower() == "true"
    
    # Trading Settings
    TAKE_PROFIT_MULTIPLIER = 2.0
    STOP_LOSS_MULTIPLIER = 0.5
    DEFAULT_BUY_AMOUNT_SOL = 0.1
