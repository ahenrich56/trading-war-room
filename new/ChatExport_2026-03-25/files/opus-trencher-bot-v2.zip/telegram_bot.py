"""
Telegram Bot v2.0 — with Whale Intelligence commands
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from config import Config
from database import Database
from wallet_manager import WalletManager
from payment_processor import PaymentProcessor
from datetime import datetime


class TelegramBot:
    def __init__(self, db: Database):
        self.db = db
        self.payment_processor = PaymentProcessor(db)
        # These will be set by main.py after initialization
        self.auto_trader = None
        self.whale_intel = None

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        username = update.effective_user.username

        user = self.db.get_user(user_id)
        if not user:
            address, private_key = WalletManager.generate_wallet()
            self.db.add_user(user_id, username, address, private_key)
            user = self.db.get_user(user_id)

        address = user[2]
        welcome_text = (
            f"🐋 Welcome to OPUS The Trencher Bot, {username}!\n\n"
            f"Your personal Solana deposit wallet:\n`{address}`\n\n"
            "Deposit SOL or OPUS tokens to this address to pay for "
            "subscriptions or use the autotrader.\n\n"
            "🔥 NEW: Whale Intelligence — track smart money & insider signals!"
        )

        keyboard = [
            [InlineKeyboardButton("💰 CHECK BALANCE", callback_data="check_balance")],
            [InlineKeyboardButton("🔑 PAY NOW", callback_data="pay_now")],
            [InlineKeyboardButton("📊 MEMBERSHIP STATUS", callback_data="membership_status")],
            [InlineKeyboardButton("🐋 WHALE ALERTS", callback_data="whale_alerts"),
             InlineKeyboardButton("📈 BOT STATUS", callback_data="bot_status")],
            [InlineKeyboardButton("👥 MY REFERRALS", callback_data="my_referrals")],
            [InlineKeyboardButton("❓ HOW IT WORKS", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(welcome_text, reply_markup=reply_markup, parse_mode="Markdown")

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        help_text = (
            "🐋 *OPUS The Trencher Bot*\n\n"
            "*HOW IT WORKS:*\n"
            "1. Deposit SOL or OPUS tokens to your unique wallet address.\n"
            "2. Select a subscription plan using PAY NOW.\n"
            "3. Once active, you'll receive real-time pump.fun signals.\n"
            "4. The Gold Au-Bot autotrader executes trades for you.\n"
            "5. Whale Intelligence tracks smart money & insider signals.\n\n"
            "*COMMANDS:*\n"
            "/start — Main menu\n"
            "/whale — Recent whale alerts\n"
            "/status — Bot & trading status\n"
            "/help — This message\n\n"
            "Share your referral link to earn 10% commission + free days!"
        )
        await update.message.reply_text(help_text, parse_mode="Markdown")

    async def whale_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show recent whale alerts."""
        if self.whale_intel:
            text = self.whale_intel.get_recent_alerts_formatted(limit=10)
        else:
            text = "Whale Intelligence is initializing..."
        await update.message.reply_text(text, parse_mode="Markdown")

    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show bot and trading status."""
        lines = ["📊 *Bot Status Report*\n"]

        if self.auto_trader:
            s = self.auto_trader.get_status()
            lines.append(f"*Auto Trader:*")
            lines.append(f"  Bankroll: {s['bankroll']}")
            lines.append(f"  Total PnL: {s['total_pnl']}")
            lines.append(f"  Daily PnL: {s['daily_pnl']}")
            lines.append(f"  Trades: {s['total_trades']} (W:{s['wins']} L:{s['losses']})")
            lines.append(f"  Win Rate: {s['win_rate']}")
            lines.append(f"  Open: {s['open_positions']}")
            lines.append(f"  Max DD: {s['max_drawdown']}")
            lines.append(f"  Paper: {'Yes' if s['paper_mode'] else 'LIVE'}\n")

        if self.whale_intel:
            w = self.whale_intel.get_status()
            lines.append(f"*Whale Intelligence:*")
            lines.append(f"  Tracked Whales: {w['tracked_whales']}")
            lines.append(f"  Alerts (1h): {w['alerts_1h']}")
            lines.append(f"  Actionable (1h): {w['actionable_1h']}")
            lines.append(f"  Total Alerts: {w['total_alerts']}")

        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    async def button_handler(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        user_id = query.from_user.id
        user = self.db.get_user(user_id)

        if query.data == "check_balance":
            address = user[2]
            sol, opus = WalletManager.get_balance(address)
            await query.edit_message_text(
                f"💰 *Wallet Balance:*\nSOL: {sol:.4f}\nOPUS: {opus:,.0f}",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 REFRESH", callback_data="check_balance"),
                     InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]), parse_mode="Markdown")

        elif query.data == "pay_now":
            keyboard = [
                [InlineKeyboardButton("Biweekly (170,000 OPUS)", callback_data="pay_biweekly")],
                [InlineKeyboardButton("Monthly (170,000 OPUS + 1.0 SOL)", callback_data="pay_monthly")],
                [InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
            ]
            await query.edit_message_text("Select a plan:", reply_markup=InlineKeyboardMarkup(keyboard))

        elif query.data.startswith("pay_"):
            plan = query.data.split("_")[1]
            success, message = self.payment_processor.process_payment(user_id, plan)
            await query.edit_message_text(
                message,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]))

        elif query.data == "membership_status":
            membership = self.db.get_membership(user_id)
            if membership and membership[3]:
                expiry = datetime.fromisoformat(membership[1])
                status = f"✅ *Status: ACTIVE*\nExpiry: {expiry.strftime('%Y-%m-%d %H:%M')}"
            else:
                status = "❌ *Status: INACTIVE*"
            await query.edit_message_text(
                status,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 RENEW", callback_data="pay_now"),
                     InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]), parse_mode="Markdown")

        elif query.data == "my_referrals":
            count = self.db.get_referral_stats(user_id)
            ref_link = f"https://t.me/{(await context.bot.get_me()).username}?start={user_id}"
            text = (f"👥 *Referral Stats:*\n"
                    f"Total Referrals: {count}\n\n"
                    f"Your Link:\n`{ref_link}`\n\n"
                    f"You get: 10% of their payment + 7 days free\n"
                    f"They get: 2 extra days of access")
            await query.edit_message_text(
                text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]), parse_mode="Markdown")

        elif query.data == "whale_alerts":
            if self.whale_intel:
                text = self.whale_intel.get_recent_alerts_formatted(limit=8)
            else:
                text = "🐋 Whale Intelligence is initializing..."
            await query.edit_message_text(
                text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 REFRESH", callback_data="whale_alerts"),
                     InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]), parse_mode="Markdown")

        elif query.data == "bot_status":
            lines = ["📊 *Bot Status*\n"]
            if self.auto_trader:
                s = self.auto_trader.get_status()
                lines.append(f"Bankroll: {s['bankroll']}")
                lines.append(f"PnL: {s['total_pnl']}")
                lines.append(f"Trades: {s['total_trades']} | WR: {s['win_rate']}")
                lines.append(f"Open: {s['open_positions']}")
                mode = "PAPER" if s['paper_mode'] else "LIVE"
                lines.append(f"Mode: {mode}")
            if self.whale_intel:
                w = self.whale_intel.get_status()
                lines.append(f"\n🐋 Whales: {w['tracked_whales']}")
                lines.append(f"Alerts (1h): {w['alerts_1h']}")
            await query.edit_message_text(
                "\n".join(lines),
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔄 REFRESH", callback_data="bot_status"),
                     InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]), parse_mode="Markdown")

        elif query.data == "help":
            help_text = (
                "🐋 *HOW IT WORKS:*\n\n"
                "1. Deposit SOL/OPUS to your wallet\n"
                "2. Select a plan via PAY NOW\n"
                "3. Get real-time pump.fun signals\n"
                "4. Auto trader executes for you\n"
                "5. Whale Intel tracks smart money\n\n"
                "*Plans:*\n"
                "• Biweekly: 170,000 OPUS (14 days)\n"
                "• Monthly: 170,000 OPUS + 1 SOL (30 days)"
            )
            await query.edit_message_text(
                help_text,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬅️ BACK", callback_data="back_to_main")]
                ]), parse_mode="Markdown")

        elif query.data == "back_to_main":
            address = user[2]
            welcome_text = (
                f"Your wallet:\n`{address}`\n\n"
                "Deposit SOL or OPUS tokens to get started."
            )
            keyboard = [
                [InlineKeyboardButton("💰 CHECK BALANCE", callback_data="check_balance")],
                [InlineKeyboardButton("🔑 PAY NOW", callback_data="pay_now")],
                [InlineKeyboardButton("📊 MEMBERSHIP STATUS", callback_data="membership_status")],
                [InlineKeyboardButton("🐋 WHALE ALERTS", callback_data="whale_alerts"),
                 InlineKeyboardButton("📈 BOT STATUS", callback_data="bot_status")],
                [InlineKeyboardButton("👥 MY REFERRALS", callback_data="my_referrals")],
                [InlineKeyboardButton("❓ HOW IT WORKS", callback_data="help")]
            ]
            await query.edit_message_text(
                welcome_text,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown")

    def run(self):
        application = Application.builder().token(Config.TELEGRAM_BOT_TOKEN).build()
        application.add_handler(CommandHandler("start", self.start))
        application.add_handler(CommandHandler("help", self.help_command))
        application.add_handler(CommandHandler("whale", self.whale_command))
        application.add_handler(CommandHandler("status", self.status_command))
        application.add_handler(CallbackQueryHandler(self.button_handler))
        return application
